#!/bin/zsh
set -eu
cd -- "${0:A:h}"

if [[ -t 0 && $# -eq 0 ]]; then
    trap 'read -r "?Pressione Enter para fechar." || true' EXIT
fi

if ! command -v python3 >/dev/null; then
    print -u2 "Instale o Python 3 de python.org e abra o instalador novamente."
    exit 1
fi

if [[ ! -x .venv/bin/python ]]; then
    python3 -m venv .venv
fi

if ! .venv/bin/python -c 'from importlib.metadata import version; import serial; assert version("esptool") == "4.13.0"' 2>/dev/null; then
    .venv/bin/python -m pip install -r requirements.txt
fi

.venv/bin/python instalar.py "$@"
