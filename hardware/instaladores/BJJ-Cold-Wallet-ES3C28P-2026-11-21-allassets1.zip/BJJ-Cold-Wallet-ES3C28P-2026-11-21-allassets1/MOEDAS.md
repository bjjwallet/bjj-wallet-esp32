# Catálogo de recebimento

A mesma lista é usada no app e no menu do firmware. São 23 redes/moedas nativas e 63 tokens. Cada combinação de rede e ativo é distinta. Esta relação não declara suporte completo de saldo, envio e assinatura.

| Rede | Moeda nativa | Tokens |
| --- | --- | --- |
| Bitcoin | BTC | — |
| Ethereum | ETH | BNB, USDT, USDC, USDS, USDe, RLUSD, EURC, BRZ |
| Tron | TRX | USDC, USDT |
| BNB Smart Chain | BNB | BRZ, USDT, LINK, USDC, USDe, XRP |
| XRP Ledger | XRP | RLUSD, USDC |
| Dogecoin | DOGE | — |
| Solana | SOL | BRLP, XRP, MON, USDT, USDC, BRZ, SKR, USDS, PYUSD, EURC, LINK, JUP |
| Cardano | ADA | SNEK, MIN, IAG, WMTX, DJED |
| Bitcoin Cash | BCH | — |
| TON | TON | USDT |
| Avalanche C-Chain | AVAX | USDT, USDC |
| Ethereum Classic | ETC | — |
| Litecoin | LTC | — |
| Arbitrum | ETH | BRZ, USDC, ARB, USDT, USDS, LINK, USDe |
| Polygon | POL | USDC, USDT, LINK, BRZ |
| Sui | SUI | USDC |
| Dash | DASH | — |
| eCash | XEC | — |
| Base | ETH | USDC, USDS, EURC, LINK, BRZ, USDe, USDT |
| Monero | XMR | — |
| Stellar | XLM | USDC, BRLP, BRZ |
| HyperEVM | HYPE | USDC, LINK |
| Robinhood Chain | ETH | USDG |


Firmware allassets1: assinatura e revisão física dos 86 ativos do catálogo. Relatório completo em app/docs/all-assets-signing-2026-11-21.md no projeto. Atualização comum preserva carteiras e pareamentos. Sem envio real ou gravação da placa nesta execução.
