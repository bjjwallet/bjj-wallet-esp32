# BJJ-Cold-Wallet para ESP32 touch

Firmware de 21/11/2026, revisão **2026.11.21-allassets1**, para a placa **LCDWIKI ES3C28P touch**, com ESP32-S3 e flash de 16 MB. Toda a interface agora opera em **landscape, 320 × 240**, girada 90° em relação à versão anterior. O display e as coordenadas do toque foram ajustados juntos; QR codes e teclados foram adaptados à largura. A revisão usa “Valor que receberá” e “Destinatário” nos dados do recebedor; “Valor devolvido à sua carteira” e “Endereço de devolução” identificam o retorno à carteira de origem. As traduções estão alinhadas nos oito idiomas do app e do hardware. Os valores, endereços e regras de assinatura não mudam. A tela de aprovação pergunta “App: assinar transferência?” e mostra o valor, a moeda, o destinatário, a taxa e a devolução à própria carteira. No app correspondente, o PIN de acesso da cold wallet é validado em cada nova sessão Bluetooth antes do pedido de assinatura; para Bitcoin, a frase de transação é um campo separado. A assinatura só começa depois da confirmação física. A frase de transação continua obrigatória conforme o fluxo do ativo.

Mantém Configurações → Dispositivos, bloqueio persistente por ID Bluetooth e PIN obrigatório. Mantém o assinador e o pareamento seguro do Monero, restrito à stagenet. O USB continua somente para alimentação durante a execução da carteira.

A atualização normal preserva carteiras, apelido, PIN e pareamentos; não apaga NVS nem altera eFuses. Para o app correspondente, a confirmação abre uma bottom sheet de conexão e aprovação. Após o envio aceito, abre a tela de transações; puxe a lista para atualizar a confirmação. No Bitcoin, o histórico de rede é consultado pela API selecionada Blockstream ou Mempool. O modo de assinatura com entrada sintética não cria registro na blockchain.

O pareamento seguro do Monero permanece ativo e a biblioteca de assinatura foi reconstruída da revisão fixada no projeto. O suporte Monero desta versão permanece restrito à stagenet. Excluir um dispositivo permite novo pareamento; bloquear recusa aquele ID até excluir o registro bloqueado. IDs novos continuam exigindo confirmação física e PIN.

Esta revisão corrige a exclusão de dispositivos: a operação é executada na tarefa
Bluetooth, pausando os anúncios durante a remoção da chave de pareamento. Os
anúncios são retomados quando aplicável. O fluxo de pareamento Monero permanece
ativo. O modo de flash DIO corresponde às opções do instalador.

O instalador normal continua preservando carteiras e pareamentos. O apagamento
completo desta sessão foi solicitado explicitamente pelo usuário e é uma operação
separada, com backup integral protegido antes de apagar.

Os idiomas seguem os mesmos nomes e a mesma ordem do BJJ-App-Wallet atualizado, incluindo a tradução japonesa no app.

**Português → English → Español → Français → 简体中文 → 日本語 → Italiano → Deutsch**

Na ESP32, escolha o idioma no visor. No app, a opção adicional **Idioma do aparelho** acompanha a preferência do Android ou iOS.

O recebimento de Cardano está disponível para ADA, SNEK, MIN, IAG, WMTX e DJED. O catálogo de recebimento corresponde ao app: 23 redes/moedas nativas e 63 tokens, com ícones. Consulte [a lista por rede](MOEDAS.md). Saldo, envio e assinatura dependem da integração de cada ativo; a presença na lista não indica envio concluído.

**O mesmo ZIP serve para Windows, Linux e macOS.** O arquivo `Instalar.command` é o atalho do Mac. No Windows e no Linux, execute `instalar.py` com Python 3 e as dependências listadas em `requirements.txt`. O instalador foi testado no macOS.

## Instalação limpa solicitada — revisão reset1

Após backup integral verificado de 16 MiB, esta revisão foi instalada do zero
por solicitação explícita do usuário. A flash foi apagada; bootloader, tabela e
aplicação foram gravados e conferidos por leitura. As áreas de carteiras e de
pareamentos estavam vazias antes do primeiro início. Quatro verificações após
o reinício por watchdog confirmaram a ausência da porta USB. Nenhum eFuse foi
alterado. A conferência visual da configuração inicial permanece com o usuário.

## Validação em 20/11/2026

O firmware foi instalado na ES3C28P touch gravando apenas a aplicação em
`0x10000`. A leitura da flash conferiu o binário completo. As partições NVS de
configurações/pareamentos e das carteiras permaneceram idênticas byte por byte;
a tabela de partições também foi preservada. Foram salvos backups protegidos
antes da gravação. Após o reinício por watchdog, quatro verificações confirmaram
a ausência da porta USB, esperada no modo de alimentação. A conferência visual
do menu no visor ainda depende do usuário. O menu **Dispositivos** é a última
opção de Configurações e aparece mesmo quando a lista está vazia.

## Atualizar no Mac

1. Se baixou o ZIP, descompacte-o e mantenha juntos todos os arquivos da pasta.
2. Conecte a placa com um cabo USB-C de dados e feche outros programas que estejam usando a porta serial. Se ela já usa esta versão com USB apenas para alimentação, entre antes no modo de gravação conforme a seção abaixo.
3. Abra **Instalar.command** e aguarde a gravação e o reinício. O Mac precisa de Python 3. A primeira execução pode precisar de internet para baixar o esptool.

O instalador verifica os arquivos e o mapa de partições. A atualização grava apenas a aplicação e preserva as carteiras, o apelido e os pareamentos. A tabela de partições deve coincidir com a da placa; não use `--placa-nova` numa carteira já configurada.

## USB apenas para alimentação durante o uso

Esta versão desconecta os dados do USB nativo assim que a aplicação da carteira inicia, antes de abrir o cofre ou iniciar o Bluetooth. A porta serial desaparece do computador; isso é esperado. O cabo continua alimentando a placa. A comunicação com o app acontece por Bluetooth. O firmware distribuído não inclui controle da tela por USB nem console USB. Wi-Fi e SD/microSD continuam bloqueados.

Esse bloqueio é por software durante a execução da carteira. Não é um corte físico do cabo nem um bloqueio permanente de USB/JTAG: o boot e o modo ROM de gravação podem usar USB. A instalação não queima eFuses. Atualizações comuns preservam as carteiras e o apelido.

Validação física em 17/11/2026: firmware instalado na ES3C28P touch e verificado na flash. As regiões de configurações e carteiras foram comparadas antes e depois da gravação e ficaram idênticas byte por byte. Após iniciar a aplicação, seis leituras durante dez segundos confirmaram a ausência da ESP32 na lista de portas seriais e na árvore USB do macOS. A compilação, a auditoria do ELF e a integridade SHA-256/ZIP também passaram.

Na placa testada, o reinício automático por RTS manteve o modo de gravação ativo. O instalador agora sai desse modo usando o reinício por watchdog fornecido pelo esptool, sem apagar flash nem alterar eFuses. Esse procedimento de saída foi validado na placa; o fluxo completo do instalador ajustado foi conferido com chamadas USB simuladas. A conferência visual após a última gravação e um novo ciclo físico BOOT/RESET ficam pendentes para a próxima utilização.

Para reinstalar ou atualizar depois que a porta desaparecer:

1. Com a placa conectada, mantenha **BOOT** pressionado.
2. Pressione e solte **RESET** (ou **RST/EN**), mantendo BOOT pressionado.
3. Solte **BOOT**. A porta USB do modo de gravação deve aparecer.
4. Execute o instalador do seu sistema operacional. Se necessário, selecione a nova porta com `--porta`.

Se a placa não tiver um botão RESET acessível, mantenha BOOT pressionado ao conectar o cabo e solte-o após a detecção. Depois da gravação e do reinício normal, o USB volta a servir apenas para alimentação. Não use `--placa-nova` em uma placa com carteiras existentes.

Se, após a gravação, a tela ainda estiver no modo de gravação e a porta USB continuar aparecendo, solte BOOT e pressione RESET uma vez, sem segurar BOOT. Para iniciar normalmente a carteira, não mantenha BOOT pressionado.

Este ZIP instala o firmware da ESP32. Para atualizar também o app, instale a nova versão sobre o BJJ-App-Wallet existente, com o mesmo identificador e assinatura. Isso permite manter as carteiras e configurações salvas.

Para abrir pelo Terminal, digite `zsh ` (com um espaço), arraste **Instalar.command** para a janela e pressione Enter. Se houver várias placas, acrescente `--porta /dev/cu.usbmodem14101`, trocando o exemplo pela porta da sua placa.

## Primeira instalação em uma placa vazia

No Terminal, abra a pasta extraída e rode:

```sh
./Instalar.command --placa-nova
```

Esse modo grava o bootloader, a tabela de partições e a aplicação quando a tabela da placa está vazia. Depois do reinício, escolha o idioma no visor. Para conferir o pacote e a compatibilidade da tabela sem gravar, acrescente `--verificar` ao comando do modo escolhido.

## Windows

Com Python 3 instalado, abra o PowerShell na pasta do pacote:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe instalar.py
```

Acrescente `--porta COM3` se precisar selecionar uma porta. Use o número mostrado no Gerenciador de Dispositivos. Para a primeira instalação em uma placa vazia, acrescente `--placa-nova` ao último comando.

## Linux

Com Python 3 instalado, abra o Terminal na pasta do pacote e execute os comandos abaixo.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python instalar.py
```

Se precisar selecionar a porta, acrescente `--porta /dev/ttyACM0` ao último comando, usando a porta da sua placa. Para instalar em uma placa vazia, acrescente `--placa-nova`.

Se a placa não for reconhecida, confira se o cabo USB transmite dados e se a porta aparece no sistema. Se a conexão falhar durante a gravação, siga as instruções do esptool para o modo de gravação. [Diagnóstico oficial da Espressif](https://docs.espressif.com/projects/esptool/en/release-v4/esp32s3/troubleshooting.html)


Firmware allassets1: assinatura e revisão física dos 86 ativos do catálogo. Relatório completo em app/docs/all-assets-signing-2026-11-21.md no projeto. Atualização comum preserva carteiras e pareamentos. Sem envio real ou gravação da placa nesta execução.
