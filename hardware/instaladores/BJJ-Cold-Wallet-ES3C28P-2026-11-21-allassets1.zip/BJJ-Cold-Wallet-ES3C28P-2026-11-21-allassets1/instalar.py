#!/usr/bin/env python3
"""Instalador USB do BJJ-Cold-Wallet para a ESP32-S3 ES3C28P touch."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
FIRMWARE = ROOT / "firmware"
APP = "airlock_board_check.bin"
TABLE = "partition_table/partition-table.bin"
BOOT = "bootloader/bootloader.bin"
FLASH_OPTIONS = ["--flash_mode", "dio", "--flash_freq", "80m", "--flash_size", "16MB"]


def verify_files():
    expected = json.loads((FIRMWARE / "sha256.json").read_text(encoding="utf-8"))
    if set(expected) != {APP, TABLE, BOOT}:
        raise ValueError("A lista de arquivos do firmware está incompleta.")
    for file, digest in expected.items():
        if hashlib.sha256((FIRMWARE / file).read_bytes()).hexdigest() != digest:
            raise ValueError(f"O arquivo {file} não passou na verificação SHA-256. Extraia o pacote novamente.")


def usb_port(explicit_port):
    if explicit_port:
        return explicit_port
    from serial.tools import list_ports

    ports = [port.device for port in list_ports.comports()
             if port.vid == 0x303A and not port.device.startswith("/dev/tty.")]
    if len(ports) != 1:
        raise ValueError("Conecte uma única ESP32 por USB ou indique a porta com --porta.")
    return ports[0]


def start_wallet(port):
    # On this board, an RTS reset can keep the ROM's GPIO0 boot strap latched
    # in download mode after physical BOOT. Use the SDK's watchdog restart,
    # clearing only the volatile force-download flag. Never write eFuses here.
    from esptool.targets.esp32s3 import ESP32S3ROM
    from esptool.util import FatalError

    esp = None
    try:
        esp = ESP32S3ROM(port, 115200)
        esp.connect(mode="no_reset")
        esp.write_reg(esp.RTC_CNTL_OPTION1_REG, 0, esp.RTC_CNTL_FORCE_DOWNLOAD_BOOT_MASK)
        esp.watchdog_reset()
    except FatalError as error:
        raise ValueError("Não foi possível sair do modo de gravação. Solte BOOT e pressione RESET para iniciar a carteira. Não use --placa-nova para repetir uma atualização.") from error
    finally:
        if esp is not None:
            esp._port.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--porta", help="Porta USB, por exemplo /dev/cu.usbmodem14101 ou COM3")
    parser.add_argument("--placa-nova", action="store_true", help="Instalação completa com tabela de partições vazia")
    parser.add_argument("--verificar", action="store_true", help="Lê a tabela da placa sem gravar")
    args = parser.parse_args()

    try:
        verify_files()
        port = usb_port(args.porta)
        esptool = [sys.executable, "-m", "esptool", "--chip", "esp32s3", "--port", port, "--baud", "460800"]
        print(f"Verificando a ESP32 em {port}...", flush=True)
        expected_table = (FIRMWARE / TABLE).read_bytes()
        with tempfile.TemporaryDirectory(prefix="bjj-instalador-") as temporary:
            readback = Path(temporary) / "particoes.bin"
            # Keep the ROM loader alive between inspection and writing: the
            # installed wallet intentionally disconnects USB when it starts.
            subprocess.run(esptool + ["--after", "no_reset", "read_flash", "0x8000", str(len(expected_table)), str(readback)], check=True)
            installed_table = readback.read_bytes()

        if args.placa_nova:
            if installed_table != b"\xff" * len(expected_table):
                raise ValueError("A tabela da placa não está vazia. Para atualizar uma instalação compatível, retire --placa-nova.")
            images = ["0x0", BOOT, "0x8000", TABLE, "0x10000", APP]
        else:
            if installed_table != expected_table:
                raise ValueError("A tabela da placa difere da versão do pacote. Use --placa-nova apenas em uma placa com a tabela vazia.")
            images = ["0x10000", APP]

        if args.verificar:
            start_wallet(port)
            print("Pacote e tabela da placa conferidos. Nenhuma gravação foi feita.")
            return
        print("Instalando o firmware na ESP32. Mantenha o cabo conectado.", flush=True)
        subprocess.run(esptool + ["--before", "no_reset", "--after", "no_reset", "write_flash"] + FLASH_OPTIONS + images, cwd=FIRMWARE, check=True)
        start_wallet(port)
        print("Instalação concluída. Após iniciar a carteira, o USB fica apenas para alimentação e a porta serial desaparece.")
    except ModuleNotFoundError:
        parser.exit(1, "Instale as dependências com python -m pip install -r requirements.txt.\n")
    except (ValueError, OSError) as error:
        parser.exit(1, f"Erro: {error}\n")
    except subprocess.CalledProcessError as error:
        parser.exit(1, f"Falha no esptool (código {error.returncode}). Confira o cabo e a porta USB. Para recuperar a porta, mantenha BOOT pressionado, pressione e solte RESET e depois solte BOOT.\n")


if __name__ == "__main__":
    main()
